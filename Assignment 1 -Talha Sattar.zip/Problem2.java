public class Problem2 {

	public static int findIndex(int arr[], int t)
	{

		//Setting range of Index
		int len = (arr.length - 3);
		int i = 1;

		// traverse in the array
		while (i < len) {

			if (arr[i] == t) {
				return i;
			}
			else {
				i = i + 1;
			}
		}
		return -1;
	}

	public static void main(String[] args)
	{
		int[] my_array = {0,1,4,3,3,3,4};

		// find the index of 4
		System.out.println("Index position of 4 is: "
						+ findIndex(my_array, 4));

	
	}
	
}