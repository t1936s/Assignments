
#Problem 2: Only count a word If the previous word a character

input_str = "I'm Talha Sattar"

count = 0

for character in input_str:
	if character >= 'a' and character <= 'z' or character >= 'A' and character <= 'Z':
		count = count + 1

# printing result
print ("Count of words : " + str(count))

