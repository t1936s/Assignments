
# Problem 1: Manage Double Spaces in String

input_string = 	'Im     Talha    Sattar, DSA  60  Day  Challenge'
output_string = []

space_flag = False # Flag true if it find spaces

for index in range(len(input_string)):

	if input_string[index] != ' ':
		if space_flag == True:
			if (input_string[index] == '.'
					or input_string[index] == '?'
					or input_string[index] == ','):
				pass
			else:
				output_string.append(' ')
			space_flag = False
		output_string.append(input_string[index])
	elif input_string[index - 1] != ' ':
		space_flag = True

print (''.join(output_string))


# In[ ]:




